# 🚀 GITHUB DESKTOP UPLOAD GUIDE - Hotel Chandamama

## 📋 WHAT YOU NEED

1. **GitHub Account** - https://github.com (sign up free)
2. **GitHub Desktop** - https://desktop.github.com (download and install)
3. **Your 3 Project Folders** (I'll provide links below)

---

## 🎯 STEP-BY-STEP GITHUB DESKTOP UPLOAD

### STEP 1: Install GitHub Desktop

1. Download from: https://desktop.github.com
2. Install the application
3. Open GitHub Desktop
4. Click "Sign in to GitHub.com"
5. Login with your GitHub account

---

### STEP 2: Create Repositories on GitHub.com

Go to https://github.com and create these 3 repositories:

#### Repository 1: Backend
- Click "New Repository" (green button)
- Name: `hotel-chandamama-backend`
- Description: `Backend API for Hotel Chandamama`
- Keep it **Public** (free)
- DON'T check "Add README"
- Click "Create repository"

#### Repository 2: Frontend  
- Click "New Repository"
- Name: `hotel-chandamama-frontend`
- Description: `Customer Website for Hotel Chandamama`
- Keep it **Public** (free)
- DON'T check "Add README"
- Click "Create repository"

#### Repository 3: Admin
- Click "New Repository"
- Name: `hotel-chandamama-admin`
- Description: `Admin Panel for Hotel Chandamama`
- Keep it **Public** (free)
- DON'T check "Add README"
- Click "Create repository"

---

### STEP 3: Upload Backend Using GitHub Desktop

1. **Open GitHub Desktop**

2. **Clone the backend repository:**
   - File → Clone Repository
   - Click "URL" tab
   - Enter: `https://github.com/YOUR_USERNAME/hotel-chandamama-backend`
   - Choose where to save on your computer
   - Click "Clone"

3. **Copy backend files:**
   - Open the folder where you saved the backend files
   - Copy ALL files from the **backend** folder I provided
   - Paste into the cloned repository folder
   - Your folder should now have:
     - controllers/
     - models/
     - routes/
     - middleware/
     - utils/
     - scripts/
     - server.js
     - package.json
     - .env.example
     - .gitignore

4. **Commit and Push:**
   - GitHub Desktop will show all new files
   - In the bottom-left:
     - Summary: `Initial backend setup`
     - Description: `Complete backend API with all features`
   - Click "Commit to main"
   - Click "Push origin" (top right)

5. **Verify:**
   - Go to GitHub.com
   - Open your backend repository
   - You should see all files!

---

### STEP 4: Upload Frontend Using GitHub Desktop

1. **In GitHub Desktop:**
   - File → Clone Repository
   - URL: `https://github.com/YOUR_USERNAME/hotel-chandamama-frontend`
   - Choose location
   - Click "Clone"

2. **Copy frontend files:**
   - Copy ALL files from **frontend** folder
   - Paste into cloned repository
   - Should have:
     - src/
     - public/
     - index.html
     - package.json
     - vite.config.js
     - tailwind.config.js
     - .env.example
     - .gitignore

3. **Commit and Push:**
   - Summary: `Initial frontend setup`
   - Description: `Customer website with all pages`
   - Click "Commit to main"
   - Click "Push origin"

---

### STEP 5: Upload Admin Using GitHub Desktop

1. **In GitHub Desktop:**
   - File → Clone Repository
   - URL: `https://github.com/YOUR_USERNAME/hotel-chandamama-admin`
   - Choose location
   - Click "Clone"

2. **Copy admin files:**
   - Copy ALL files from **admin** folder
   - Paste into cloned repository
   - Should have:
     - src/
     - public/
     - index.html
     - package.json
     - vite.config.js
     - tailwind.config.js
     - .env.example
     - .gitignore

3. **Commit and Push:**
   - Summary: `Initial admin panel setup`
   - Description: `Admin panel with authentication`
   - Click "Commit to main"
   - Click "Push origin"

---

## ✅ VERIFICATION

Go to GitHub.com and check all 3 repositories have files!

Your GitHub URLs will be:
1. https://github.com/YOUR_USERNAME/hotel-chandamama-backend
2. https://github.com/YOUR_USERNAME/hotel-chandamama-frontend
3. https://github.com/YOUR_USERNAME/hotel-chandamama-admin

---

## 🌐 NEXT: DEPLOYMENT

After files are on GitHub, deploy to:

### Backend → Render.com
1. Go to https://render.com
2. Sign up (use GitHub account)
3. New Web Service
4. Connect your `hotel-chandamama-backend` repository
5. Follow DEPLOYMENT_GUIDE.md for details

**Your Backend URL will be:**
```
https://hotel-chandamama-api.onrender.com
```

### Frontend → Vercel.com
1. Go to https://vercel.com
2. Sign up (use GitHub account)
3. Import Project
4. Select `hotel-chandamama-frontend`
5. Deploy

**Your Frontend URL will be:**
```
https://hotel-chandamama-frontend.vercel.app
```

Then connect custom domain:
```
https://www.hotel-chandamama-vinukonda.com
```

### Admin → Vercel.com
1. Import Project
2. Select `hotel-chandamama-admin`
3. Deploy

**Your Admin URL will be:**
```
https://hotel-chandamama-admin.vercel.app
```

Optional custom domain:
```
https://admin.hotel-chandamama-vinukonda.com
```

---

## 📱 QR CODE

After frontend is deployed, create QR code for:
```
https://www.hotel-chandamama-vinukonda.com/menu
```

Use: https://www.qr-code-generator.com/

---

## 🆘 TROUBLESHOOTING

**GitHub Desktop not showing files?**
→ Make sure you're in the right folder
→ Check you pasted files in the cloned repository folder

**Push failed?**
→ Make sure you're logged into GitHub Desktop
→ Check your internet connection
→ Try: Repository → Pull before pushing

**Files missing on GitHub?**
→ Check you committed and pushed
→ Refresh the GitHub webpage

---

## 📞 REMEMBER TO UPDATE

After deployment, update phone number in:
- frontend/src/components/Navbar.jsx
- frontend/src/components/Footer.jsx
- frontend/src/pages/Contact.jsx
- frontend/src/pages/Catering.jsx

Replace: `+919876543210` with YOUR number

Then commit and push again!

---

## ✨ YOU'RE DONE!

Once all 3 repositories are on GitHub:
1. Deploy backend on Render
2. Deploy frontend on Vercel
3. Deploy admin on Vercel
4. Connect custom domain
5. Create QR code
6. Upload hotel images
7. Test everything!

Total time: 30-60 minutes

Good luck! 🎉
